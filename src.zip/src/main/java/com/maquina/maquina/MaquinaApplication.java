package com.maquina.maquina;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaquinaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaquinaApplication.class, args);
	}

}
